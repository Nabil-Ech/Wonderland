# Setup

```bash
forge install transmissions11/solmate --no-git
```

## handy-command

```bash
forge install foundry-rs/forge-std@v1.7.1 --no-commit
```
