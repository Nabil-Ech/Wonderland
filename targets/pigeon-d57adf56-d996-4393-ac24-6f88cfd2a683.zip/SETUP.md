# Setup

```bash
forge install OpenZeppelin/openzeppelin-contracts-upgradeable@v5.5.0 --no-git
```

## handy-command

```bash
forge install foundry-rs/forge-std@v1.15.0 --no-commit
```
